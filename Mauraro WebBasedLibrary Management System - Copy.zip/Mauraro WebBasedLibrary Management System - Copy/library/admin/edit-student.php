<?php
include('includes/config.php');
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM tblstudents WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_STR);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_ASSOC);
}
?>

<!-- HTML form for editing student information -->
<form method="post" action="update-student.php">
    <!-- Include input fields pre-filled with student details -->
    <!-- Example: -->
    <input type="hidden" name="student_id" value="<?php echo htmlentities($result['id']); ?>">
    <input type="text" name="full_name" value="<?php echo htmlentities($result['FullName']); ?>">
    <input type="text" name="email" value="<?php echo htmlentities($result['EmailId']); ?>">
    <input type="text" name="mobile_number" value="<?php echo htmlentities($result['MobileNumber']); ?>">
    
    <!-- Add a submit button to update student details -->
    <button type="submit" name="update">Update</button>
</form>

