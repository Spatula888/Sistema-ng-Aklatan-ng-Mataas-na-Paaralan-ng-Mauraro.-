<?php
session_start();
error_reporting(0);
include('includes/config.php');

if(strlen($_SESSION['login']) == 0) {
    header('location:index.php');
} else {
    if(isset($_GET['id'])) {
        $bookId = $_GET['id']; // Fetch the book ID from the GET parameter

        // Fetch book details from the database based on the book ID
        $sql = "SELECT * FROM tblbooks WHERE id = :bookId";
        $query = $dbh->prepare($sql);
        $query->bindParam(':bookId', $bookId, PDO::PARAM_INT);
        $query->execute();
        $book = $query->fetch(PDO::FETCH_ASSOC);

        // If the book exists and is available for borrowing
        if($book && $book['isIssued'] == '0') {
            // Perform the borrowing action
            $userId = $_SESSION['user_id']; // Assuming you have a user ID stored in the session

            // Update book status to 'Issued' in the database
            $updateSql = "UPDATE tblbooks SET isIssued = '1' WHERE id = :bookId";
            $updateQuery = $dbh->prepare($updateSql);
            $updateQuery->bindParam(':bookId', $bookId, PDO::PARAM_INT);
            $updateQuery->execute();

            // Insert a record into the issued book details table
            $insertSql = "INSERT INTO tblissuedbookdetails(BookId, StudentID) VALUES (:bookId, :userId)";
            $insertQuery = $dbh->prepare($insertSql);
            $insertQuery->bindParam(':bookId', $bookId, PDO::PARAM_INT);
            $insertQuery->bindParam(':userId', $userId, PDO::PARAM_INT);
            $insertQuery->execute();

            // Redirect back to the listed-books.php page after borrowing
            header('location: listed-books.php');
            exit;
        } else {
            // Book is not available for borrowing or doesn't exist
            // Handle this scenario, display a message or redirect to another page
        }
    } else {
        // Redirect to a different page or display an error if the book ID is not provided
    }
}
?>
